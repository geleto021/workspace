import java.util.Scanner;


public class SumTwoNumbers {

	public static void main(String[] args) {
Scanner in = new Scanner(System.in);
int i = in.nextInt();
int y = in.nextInt();
int sum = i+y;
System.out.println(sum);
	}

}
